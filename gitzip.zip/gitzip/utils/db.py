from sqlalchemy import text, create_engine,MetaData,Table,Column,Integer,String,insert,select
from sqlalchemy.orm import sessionmaker
import os
import dotenv
from sqlalchemy.orm import declarative_base

Base = declarative_base()
dotenv.load_dotenv()

POSTGRES_USER=os.getenv('POSTGRES_USER')
POSTGRES_PASSWORD=os.getenv('POSTGRES_PASSWORD')
POSTGRES_PORT=os.getenv('POSTGRES_PORT')
POSTGRES_DATABASE=os.getenv('POSTGRES_DATABASE')

engine = create_engine(f'postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@localhost:{POSTGRES_PORT}/{POSTGRES_DATABASE}')
SessionLocal =sessionmaker(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


