from fastapi import FastAPI, Depends,HTTPException
from sqlalchemy.orm import Session
from utils.auth import *
from utils.db import get_db,Base,engine
from models import *
from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    print("Tables created (if not exist)")    
    yield

app = FastAPI(lifespan=lifespan)

@app.post("/signup", response_model=UserResponse)
def signup(user: UserCreate, db: Session = Depends(get_db)):
    new_user = User(
        email=user.email,
        password=hashpassword(user.password),
        name=user.name,
        phone=user.phone,
        is_admin=user.is_admin
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return new_user

@app.post("/login")
def login(user:UserLogin,db:Session=Depends(get_db)):
    db_user = None
    if user.email:
        db_user = db.query(User).filter(User.email == user.email).first()
    elif user.phone:
        db_user = db.query(User).filter(User.phone == user.phone).first()
    else:
        raise HTTPException(status_code=400, detail="Email or phone required")
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    if not verify_password(user.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"user_id": str(db_user.id)})
    return {
        "access_token": token,
        "token_type": "Bearer"
    }

@app.post("/books", response_model=BookResponse)
def create_book(book: BookCreate, db: Session = Depends(get_db)):

    existing = db.query(Book).filter(Book.isbn == book.isbn).first()
    if existing:
        raise HTTPException(status_code=400, detail="Book already exists")

    new_book = Book(**book.model_dump())

    db.add(new_book)
    db.commit()
    db.refresh(new_book)

    return new_book

@app.get("/books", response_model=list[BookResponse])
def get_books(db: Session = Depends(get_db)):
    books = db.query(Book).all()
    return books


@app.post("/borrow", response_model=BorrowResponse)
def borrow_book(borrow: BorrowCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    book = db.query(Book).filter(Book.id == borrow.book_id).first()
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")

    if book.copies_available <= 0:
        raise HTTPException(status_code=400, detail="No copies available")

    borrow_record = Borrow(
        id="",
        user_id="",
        book_id="",
        borrowed_at="",
        returned_at=""
        )

    book.copies_available -= 1

    db.add(borrow_record)
    db.commit()
    db.refresh(borrow_record)
    return BorrowResponse