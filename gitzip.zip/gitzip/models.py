from pydantic import BaseModel, Field, EmailStr,field_validator
from typing import List, Optional
from datetime import datetime, timezone
from utils.db import Base
from sqlalchemy import Column, Integer, String, DateTime,Boolean,ForeignKey

#SQL MODELS
class User(Base):   
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String)
    name = Column(String)
    phone = Column(String)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    is_admin=Column(Boolean,default=False)

class Book(Base):
    __tablename__ = "books"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    author = Column(String, nullable=False)
    description = Column(String, nullable=True)
    isbn = Column(String, unique=True)
    copies_available = Column(Integer, default=1)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class Borrow(Base):
    __tablename__ = "borrows"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    book_id = Column(Integer, ForeignKey("books.id"))
    borrowed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    returned = Column(Boolean, default=False)
    
#PYDANTIC MODELS
class BookCreate(BaseModel):
    title: str
    author: str
    description: str | None = None
    isbn: str
    copies_available: int = Field(ge=1)

class BorrowCreate(BaseModel):
    book_id: int

class BorrowResponse(BaseModel):
    id: int
    book_id: int
    user_id: int
    borrowed_at: Optional[datetime]
    returned_at: Optional[datetime]

    class Config:
        from_attributes = True  

class BookResponse(BaseModel):
    id: int
    title: str
    author: str
    description: str
    isbn: str
    copies_available: int

    class Config:
        orm_mode = True

# class Book(BaseModel):
#     name: str = Field(max_length=100)
#     description: str = Field(max_length=500)
#     tags: List[str] = []
#     available: bool = True
#     created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class BorrowRecord(BaseModel):
    user_email: EmailStr
    book_name: str
    borrowed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    returned_at: Optional[datetime] = None

class UserCreate(BaseModel):
    email: EmailStr
    name:str=Field(max_length=40)
    password: str = Field(max_length=72)
    phone:str=Field(min_length=10,max_length=15)
    is_admin:bool=False
    @field_validator("phone")
    def validate_phone(cls, v):
        if not v.isdigit():
            raise ValueError("Phone must contain only digits")
        return v

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    name: str
    phone: str
    created_at: datetime

    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    password: str

    @field_validator("phone")
    def validate_phone(cls, v):
        if v and not v.isdigit():
            raise ValueError("Phone must contain only digits")
        return v